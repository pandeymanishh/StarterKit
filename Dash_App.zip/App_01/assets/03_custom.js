$('.menu .item')
  .tab()
;
