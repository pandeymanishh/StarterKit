import dash
import dash_html_components as html
import dash_core_components as dcc
from dash.dependencies import Input, Output, State
import os
os.chdir('F:\\Learning\\Python Stuff\\\Plotly_Dash\\App_01')
'''
A multi tab app
Tab1 -
Allow for multiple file upload of type doc,docx and pdf
use Apache tika to read the pdf
Create and render a html table
Columns : File Name, Match Flag ( a tick box), Input box
Save input box to a db in sqlite
Allow download of the file with a link

Tab2 -
Use plotly to vizualize data
# Use two dropdowns to select a x and y , if
# Show multiple graphs in a grid
'''
# Initialize the application
app = dash.Dash()
app.config['suppress_callback_exceptions']=True
# Add the banner
banner_portion = html.Div(html.H2([html.Img(src = "static/wellslogo.png"
                                                  , className="ui image")
                                , html.Div("Dash Application", className="content")]
                               , className = "ui red header")
                     , className="ui basic segment")

# Dash Explaination
dash_explain = html.Div([html.Div("Dash offers a lot of amazing possibilities to build and deploy   models"
                         , className="ui header")
                        , html.Div([html.Div([html.Img(src="static/python.jpg"
                                                     , className="ui avatar image")
                                            , html.Div("Full pythonic force", className = "content")]
                                           , className="item")
                                   , html.Div([html.Img(src="static/sklearn.png"
                                                     , className="ui avatar image")
                                              , html.Div("Build sklearn models", className = "content")]
                                             , className="item")
                                   , html.Div([html.Img(src="static/spark.png"
                                                        , className="ui avatar image")
                                               , html.Div("Connect to spark api", className = "content")]
                                              , className="item")]
                                , className="ui middle aligned selection list")]
                        , className="ui basic segment")
# Style the tabs
tab_style = {
    'border': 'none',
    'backgroundColor': 'white',
    'padding':'6px'
}

tab_selected_style = {
    'borderTop': '2px solid red',
    'borderBottom': 'none',
    'borderLeft': 'none',
    'borderRight': 'none',
    'backgroundColor': 'white',
    'padding': '6px',
    'color':'red'
}


# Add the tabs
tab_addition = html.Div([dcc.Tabs(id = "tabs", value = "tab_1"
                                  , children=[dcc.Tab(label = "Data Analysis & Viz"
                                                      , value="tab_1"
                                                      , style=tab_style
                                                      , selected_style=tab_selected_style)
                                              , dcc.Tab(label = "PDF Text Extraction"
                                                        , value = "tab_2"
                                                        , style=tab_style
                                                        , selected_style=tab_selected_style)]
                                  , style = {'height':'40px', 'width':'50%'})
                         , html.Br()
                         , html.Div(id = "tab_content", className="ui red segment")]
                        , className = "ui basic segment")


# Final Layout
app.layout = html.Div( [banner_portion, dash_explain, html.Div(className="ui divider"), tab_addition]
                      , className="ui raised segment")

# Add a file uploader
upload_component = dcc.Upload(id='upload_data'
                               , children=html.Div(['Drag and Drop or '
                                                    ,html.A('Select Files')])
                               , style={'height': '100%',
                                        'borderWidth': '1px',
                                        'borderStyle': 'dashed',
                                        'borderRadius': '5px',
                                        'textAlign': 'center', 'padding':'7px'},
                        multiple=False)
# Add a dropdown for separator
sep_dropdown = dcc.Dropdown(options=[{'label': 'Comma ( , )', 'value': ','},
                                     {'label': 'Pipe ( | )', 'value': '|'},
                                     {'label': r'Tab ( \t )', 'value': r'\t'}]
                            , id='field_sep'
                            , style={'width':'100%', 'height':'100%'}
                            , placeholder="Select Field Separator")
# Submit File and Separator selection
file_submit = html.Button(id = "file_submit"
                          , n_clicks = 0
                          , children="Submit"
                          , className="ui primary button")
# Pleaseholder for a y variable

# Placeholder for x variable
# Select Chart type
# x sring, y string : Count bar chart multiple
# x string y numeric : Average bar Chart
# x numeric y numeric : scatter Chart
# x numeric y string : horizontal bar chart


# Define the callback for tabs
@app.callback(Output('tab_content', 'children'), [Input('tabs', 'value')])
def tab_contents(tab):
    if tab=='tab_1':
        return [html.Div([html.Div(upload_component, className="ui six wide column")
                         , html.Div(sep_dropdown, className="ui four wide column")
                         , html.Div(file_submit, className="ui two wide column")]
                       , className="ui grid")
                , html.Div([html.Div(id='filename', className="ui eight wide column")], className="ui grid")]
    elif tab=='tab_2':
        return "We have got tab2"

# Call back to get the filename and date modified
@app.callback(Output('filename', 'children')
              ,[Input('file_submit', 'n_clicks')]
              ,[State('upload_data', 'filename')
                , State('upload_data', 'last_modified')
                , State('field_sep', 'value')])
def update_details(n_clicks, filename, date_modified, field_sep):
    return "The uploaded file is : {}, and it was last modified on : {}, Separator choosen is {} ".format(filename, date_modified, field_sep)

if __name__ == '__main__':
    app.run_server(debug=True)
